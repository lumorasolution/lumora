# Lumora Solution — Project Plan

## Project Overview
**Brand:** Lumora Solution  
**Tagline:** Light the way in. Build the brand out.  
**Service:** Thailand Destination Thailand Visa (DTV) consultancy  
**Domain:** https://lumorasolution.org/  
**Design Template:** VEX dark theme (Space Grotesk + JetBrains Mono, glass morphism, tech grid)

---

## Phase 1 — Foundation (COMPLETED)
- [x] Restore VEX dark design system (CSS, fonts, tailwind)
- [x] Rebuild Navbar — VEX glass style with Lumora branding + DTV nav links
- [x] Rebuild Footer — VEX dark style with Lumora content + legal links
- [x] Rebuild Home page — 7 sections in VEX dark theme:
  - Hero (dark bg image, badge, headline, CTAs)
  - Stats Marquee (animated scrolling stats)
  - Value Intro (6 feature cards in glass-card grid)
  - Pricing Preview (58,000 THB package card)
  - What's Included (checklist)
  - How It Works Preview (4 step cards)
  - Trust Section (4 trust cards + tag pills)
  - Final CTA (WhatsApp + Email)
- [x] Update router config

## Phase 2 — Inner Pages (COMPLETED)
- [x] DTV Visa page — key facts grid, requirements, timeline, eligibility CTA
- [x] How It Works page — 4 detailed steps with connector lines, CTA
- [x] Pricing page — full breakdown, what's included, refund guarantee
- [x] FAQ page — 9 questions with accordion, CTA
- [x] Contact page — channel cards (WhatsApp/LINE/Email), response time box, contact form with Readdy Form API + anti-spam honeypot

## Phase 3 — Legal Pages (COMPLETED)
- [x] Privacy Policy page
- [x] Terms of Service page
- [x] Refund Policy page

## Design System
- **Background:** #050505 (dark), #080808 (section alt)
- **Fonts:** Space Grotesk (display/body), JetBrains Mono (mono/labels)
- **Effects:** liquid-glass nav, glass-card containers, tech-grid backgrounds, title-shimmer, hover-shine
- **Primary CTA:** White button on dark (`bg-white text-black`)
- **Secondary CTA:** Glass card button (`glass-card text-white/80`)

## Pending
- [ ] LINE ID / link — currently using placeholder `#`
- [ ] Legal company name / country / tax ID — if available