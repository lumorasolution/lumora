import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function Footer() {
  const { t } = useTranslation();
  const year = new Date().getFullYear();

  return (
    <footer className="relative bg-[#0f0c08] text-[#f5f0e8] border-t border-[#d9b482]/5 overflow-hidden">
      <div className="absolute inset-0 tech-grid tech-grid-mask opacity-40 pointer-events-none" />
      <div className="relative max-w-7xl mx-auto px-6 md:px-10 lg:px-16 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-9 h-9 flex items-center justify-center rounded-md bg-white text-black font-bold">L</span>
              <span className="text-2xl font-semibold tracking-tight font-display">{t('nav.brandName')}</span>
            </div>
            <p className="text-white/60 max-w-md text-sm leading-relaxed">
              {t('footer.brandDesc')}
            </p>
            <div className="mt-6 flex items-center gap-3">
              {[
                { icon: 'whatsapp', href: `https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`, label: t('footer.whatsapp') },
                { icon: 'mail', href: 'mailto:info@lumorasolution.org', label: 'Email' },
              ].map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="w-10 h-10 flex items-center justify-center rounded-lg border border-white/10 text-white/70 hover:text-white hover:border-white/30 transition-colors"
                  aria-label={item.label}
                >
                  <i className={`ri-${item.icon}-line text-base`}></i>
                </a>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-mono uppercase text-white/40 mb-4 tracking-widest">{t('footer.services')}</div>
            <ul className="space-y-3 text-sm">
              <li><Link to="/dtv-visa" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.dtvVisa')}</Link></li>
              <li><Link to="/how-it-works" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.howItWorks')}</Link></li>
              <li><Link to="/pricing" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.pricing')}</Link></li>
              <li><Link to="/faq" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.faq')}</Link></li>
            </ul>
          </div>

          <div>
            <div className="text-xs font-mono uppercase text-white/40 mb-4 tracking-widest">{t('footer.connect')}</div>
            <ul className="space-y-3 text-sm">
              <li><a href="mailto:info@lumorasolution.org" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">info@lumorasolution.org</a></li>
              <li><a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.whatsapp')}</a></li>
              <li><Link to="/contact" className="text-white/80 hover:text-white transition-colors whitespace-nowrap">{t('footer.contact')}</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-14 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-white/40 font-mono">
          <div>{t('footer.copyright').replace('{year}', String(year))}</div>
          <div className="flex flex-wrap gap-6">
            <Link to="/privacy" className="hover:text-white transition-colors whitespace-nowrap">{t('footer.privacy')}</Link>
            <Link to="/terms" className="hover:text-white transition-colors whitespace-nowrap">{t('footer.terms')}</Link>
            <Link to="/refund" className="hover:text-white transition-colors whitespace-nowrap">{t('footer.refund')}</Link>
          </div>
        </div>
        <div className="mt-4 text-xs text-white/30 font-mono text-center">
          {t('footer.disclaimer')}
        </div>
      </div>
    </footer>
  );
}