import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const languages = [
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'tr', label: 'Türkçe', flag: '🇹🇷' },
  { code: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
];

interface NavbarProps {
  transparent?: boolean;
}

export default function Navbar({ transparent = false }: NavbarProps) {
  const { t, i18n } = useTranslation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // RTL and lang attribute
  useEffect(() => {
    const lang = i18n.language;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [i18n.language]);

  useEffect(() => {
    setMobileOpen(false);
    setLangOpen(false);
  }, [location.pathname]);

  const changeLanguage = (code: string) => {
    i18n.changeLanguage(code);
    setLangOpen(false);
  };

  const navLinks = [
    { label: t('nav.aboutDtv'), to: '/dtv-visa' },
    { label: t('nav.howItWorks'), to: '/how-it-works' },
    { label: t('nav.pricing'), to: '/pricing' },
    { label: t('nav.faq'), to: '/faq' },
    { label: t('nav.contact'), to: '/contact' },
  ];

  const showSolid = !transparent || scrolled;
  const currentLang = languages.find((l) => l.code === i18n.language) || languages[0];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 px-4 md:px-8 lg:px-12 transition-all duration-500 navbar-entrance ${
        showSolid ? 'pt-3' : 'pt-6'
      }`}
    >
      <div
        className={`mx-auto max-w-7xl liquid-glass rounded-2xl flex items-center justify-between px-4 py-2 transition-all duration-500 ${
          showSolid ? 'bg-black/70' : ''
        }`}
      >
        <Link to="/" className="flex items-center gap-2 group">
          <span className="w-8 h-8 flex items-center justify-center rounded-md bg-white text-black font-bold tracking-tight">
            L
          </span>
          <span className="text-xl font-semibold tracking-tight font-display whitespace-nowrap">
            {t('nav.brandName')}
          </span>
        </Link>

        <div className="hidden md:flex gap-1 text-sm">
          {navLinks.map((link) => {
            const active = location.pathname === link.to;
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`relative px-4 py-2 rounded-lg transition-colors hover-shine whitespace-nowrap ${
                  active ? 'text-white' : 'text-white/70 hover:text-white'
                }`}
              >
                {link.label}
                {active && (
                  <span className="absolute left-3 right-3 -bottom-0.5 h-px bg-gradient-to-r from-transparent via-white to-transparent" />
                )}
              </Link>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          {/* Language Switcher */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setLangOpen((v) => !v)}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-2 rounded-lg text-sm text-white/70 hover:text-white transition-colors cursor-pointer"
              aria-label={t('lang.switchTo')}
            >
              <span className="text-base">{currentLang.flag}</span>
              <span className="text-xs font-mono uppercase hidden lg:inline">{currentLang.code}</span>
              <i className={`${langOpen ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-xs`}></i>
            </button>
            {langOpen && (
              <div className="absolute right-0 top-full mt-2 liquid-glass rounded-xl bg-black/90 p-1.5 min-w-[160px] z-50">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => changeLanguage(lang.code)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer whitespace-nowrap ${
                      i18n.language === lang.code
                        ? 'bg-white/10 text-white'
                        : 'text-white/70 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span className="text-base">{lang.flag}</span>
                    <span>{lang.label}</span>
                    {i18n.language === lang.code && (
                      <i className="ri-check-line text-xs ml-auto"></i>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          <Link
            to="/contact"
            className="hidden sm:inline-flex bg-white text-black px-5 py-2 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors"
          >
            {t('nav.freeCheck')}
          </Link>
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden w-9 h-9 flex items-center justify-center rounded-lg border border-white/15 text-white cursor-pointer"
            aria-label={t('nav.toggleMenu')}
          >
            <i className={`ri-${mobileOpen ? 'close' : 'menu'}-line text-lg`}></i>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden mx-auto max-w-7xl overflow-hidden transition-all duration-500 ${
          mobileOpen ? 'max-h-[600px] mt-3' : 'max-h-0'
        }`}
      >
        <div className="liquid-glass rounded-2xl p-4 flex flex-col gap-1 bg-black/80">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="px-3 py-2 rounded-lg text-sm text-white/80 hover:text-white hover:bg-white/5 transition-colors whitespace-nowrap"
            >
              {link.label}
            </Link>
          ))}
          {/* Mobile language options */}
          <div className="border-t border-white/10 mt-2 pt-2">
            <p className="px-3 py-1 text-[10px] font-mono uppercase text-white/30">{t('lang.switchTo')}</p>
            <div className="grid grid-cols-3 gap-1 mt-1">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => {
                    changeLanguage(lang.code);
                    setMobileOpen(false);
                  }}
                  className={`px-3 py-2 rounded-lg text-xs text-center transition-colors cursor-pointer ${
                    i18n.language === lang.code
                      ? 'bg-white/10 text-white'
                      : 'text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="text-sm block">{lang.flag}</span>
                  <span className="mt-0.5 block">{lang.code.toUpperCase()}</span>
                </button>
              ))}
            </div>
          </div>
          <Link
            to="/contact"
            className="mt-2 bg-white text-black px-4 py-2 rounded-lg text-sm font-medium text-center"
          >
            {t('nav.freeCheck')}
          </Link>
        </div>
      </div>
    </nav>
  );
}