import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="bg-[#050505] text-white min-h-screen flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <div className="text-8xl font-display font-semibold text-white/5 mb-6">404</div>
        <h1 className="text-2xl font-display font-semibold tracking-tight mb-3">Page Not Found</h1>
        <p className="text-white/40 text-sm mb-8 leading-relaxed">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 bg-white text-black px-6 py-3 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors"
        >
          <i className="ri-arrow-left-line"></i>
          Back to Home
        </Link>
      </div>
    </div>
  );
}