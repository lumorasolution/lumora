import { useState } from 'react';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { useTranslation } from 'react-i18next';

export default function Contact() {
  const { t } = useTranslation();
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [formError, setFormError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const honeypot = (form.elements.namedItem('website_alt') as HTMLInputElement)?.value?.trim();
    if (honeypot) { setFormStatus('success'); form.reset(); return; }
    setFormStatus('sending'); setFormError('');
    try {
      const formData = new FormData(form);
      const res = await fetch('https://readdy.ai/api/form/d9hitsohpes2mi34ros0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(formData as unknown as Record<string, string>).toString(),
      });
      const responseText = await res.text();
      let parsed: Record<string, unknown> = {};
      try { parsed = JSON.parse(responseText); } catch { /* use raw */ }
      if (res.ok && (parsed as { code?: string })?.code === 'OK') { setFormStatus('success'); form.reset(); }
      else { const msg = (parsed as { meta?: { message?: string } })?.meta?.message || (parsed as { message?: string })?.message || responseText || 'Something went wrong.'; setFormError(msg); setFormStatus('error'); }
    } catch { setFormError('Network error. Please try again.'); setFormStatus('error'); }
  };

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main className="pt-28 pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('contact.sectionLabel')}</p>
            <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-4">{t('contact.heading')}</h1>
            <p className="text-white/40 text-sm max-w-md mx-auto">{t('contact.subtitle')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-16">
            {[
              { icon: 'ri-whatsapp-line', title: t('contact.whatsappTitle'), detail: t('contact.whatsappDetail'), href: `https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`, btn: t('contact.whatsappBtn'), isPrimary: true },
              { icon: 'ri-mail-line', title: t('contact.emailTitle'), detail: t('contact.emailDetail'), href: 'mailto:info@lumorasolution.org', btn: t('contact.emailBtn'), isPrimary: false },
            ].map((channel) => (
              <div key={channel.title} className="glass-card rounded-2xl p-6 text-center group">
                <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-white/5 border border-white/5 mb-4 mx-auto group-hover:border-white/15 transition-colors">
                  <i className={`${channel.icon} text-white/70 text-xl`}></i>
                </div>
                <h3 className="text-white font-medium mb-1 text-sm">{channel.title}</h3>
                <p className="text-white/40 text-xs mb-4 font-mono">{channel.detail}</p>
                <a href={channel.href} target={channel.title !== t('contact.emailTitle') ? '_blank' : undefined} rel={channel.title !== t('contact.emailTitle') ? 'noopener noreferrer' : undefined}
                  className={`w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap cursor-pointer transition-all ${channel.isPrimary ? 'bg-white text-black hover:bg-gray-100' : 'glass-card text-white/80 hover:text-white'}`}>
                  {channel.btn}
                </a>
              </div>
            ))}
          </div>

          <div className="glass-card rounded-2xl p-6 mb-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 shrink-0">
                <i className="ri-timer-line text-white/60 text-sm"></i>
              </div>
              <div className="text-sm">
                <span className="text-white/70">{t('contact.responseWhatsApp')}</span>
                <span className="text-white/30">{t('contact.responseFastest')}</span>
                <span className="text-white/50 mx-1">·</span>
                <span className="text-white/70">{t('contact.responseEmail')}</span>
                <span className="text-white/30">{t('contact.responseTime')}</span>
              </div>
            </div>
          </div>

          <div className="max-w-xl mx-auto">
            <h2 className="text-2xl font-display font-semibold tracking-tight mb-2 text-center">{t('contact.formTitle')}</h2>
            <p className="text-white/30 text-xs text-center mb-8">{t('contact.formSubtitle')}</p>

            <form onSubmit={handleSubmit} data-readdy-form className="glass-card rounded-2xl p-6 md:p-8 space-y-5">
              <input type="text" name="website_alt" tabIndex={-1} autoComplete="off" aria-hidden="true" readOnly className="hp-field" />

              <div>
                <label htmlFor="fullName" className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-2">{t('contact.formFullName')}</label>
                <input id="fullName" name="fullName" type="text" required className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors" placeholder={t('contact.formFullNamePlaceholder')} />
              </div>
              <div>
                <label htmlFor="email" className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-2">{t('contact.formEmail')}</label>
                <input id="email" name="email" type="email" required className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors" placeholder={t('contact.formEmailPlaceholder')} />
              </div>
              <div>
                <label htmlFor="nationality" className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-2">{t('contact.formNationality')}</label>
                <input id="nationality" name="nationality" type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors" placeholder={t('contact.formNationalityPlaceholder')} />
              </div>
              <div>
                <label htmlFor="subject" className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-2">{t('contact.formSubject')}</label>
                <select id="subject" name="subject" className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-white/30 transition-colors appearance-none cursor-pointer">
                  <option value="Eligibility Check" className="bg-[#111] text-white">{t('contact.formSubject1')}</option>
                  <option value="DTV Application Question" className="bg-[#111] text-white">{t('contact.formSubject2')}</option>
                  <option value="Family Visa Question" className="bg-[#111] text-white">{t('contact.formSubject3')}</option>
                  <option value="General Inquiry" className="bg-[#111] text-white">{t('contact.formSubject4')}</option>
                </select>
              </div>
              <div>
                <label htmlFor="message" className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-2">{t('contact.formMessage')}</label>
                <textarea id="message" name="message" required maxLength={500} rows={4} className="w-full bg-white/[0.03] border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors resize-none" placeholder={t('contact.formMessagePlaceholder')} />
                <p className="text-white/20 text-[10px] font-mono mt-1 text-right">{t('contact.formMaxChars')}</p>
              </div>

              {formStatus === 'success' && (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <i className="ri-checkbox-circle-line text-emerald-400"></i>
                  <p className="text-emerald-300 text-sm">{t('contact.formSuccess')}</p>
                </div>
              )}
              {formStatus === 'error' && formError && (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                  <i className="ri-error-warning-line text-red-400"></i>
                  <p className="text-red-300 text-sm">{formError}</p>
                </div>
              )}

              <button type="submit" disabled={formStatus === 'sending'} className="w-full bg-white text-black px-6 py-3.5 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2">
                {formStatus === 'sending' ? <><i className="ri-loader-4-line animate-spin"></i>{t('contact.formSending')}</> : <><i className="ri-send-plane-line"></i>{t('contact.formSend')}</>}
              </button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}