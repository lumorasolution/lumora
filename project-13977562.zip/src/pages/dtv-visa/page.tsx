import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function DtvVisa() {
  const { t } = useTranslation();

  const facts = [
    { icon: 'ri-calendar-line', label: t('dtvVisa.fact1') },
    { icon: 'ri-timer-line', label: t('dtvVisa.fact2') },
    { icon: 'ri-add-circle-line', label: t('dtvVisa.fact3') },
    { icon: 'ri-group-line', label: t('dtvVisa.fact4') },
    { icon: 'ri-computer-line', label: t('dtvVisa.fact5') },
    { icon: 'ri-bank-line', label: t('dtvVisa.fact6') },
  ];

  const reqs = [t('dtvVisa.req1'), t('dtvVisa.req2'), t('dtvVisa.req3'), t('dtvVisa.req4'), t('dtvVisa.req5')];

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main className="pt-28 pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('dtvVisa.sectionLabel')}</p>
            <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-6">
              {t('dtvVisa.heading1')}{' '}<span className="title-shimmer">{t('dtvVisa.heading2')}</span>{t('dtvVisa.headingSuffix')}
            </h1>
            <p className="text-white/40 max-w-2xl mx-auto text-sm leading-relaxed">{t('dtvVisa.subtitle')}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-20">
            {facts.map((fact) => (
              <div key={fact.label} className="glass-card rounded-2xl p-6 flex items-start gap-4 group">
                <div className="w-10 h-10 flex items-center justify-center shrink-0 rounded-lg bg-white/5 border border-white/5 group-hover:border-white/15 transition-colors">
                  <i className={`${fact.icon} text-white/60 text-lg`}></i>
                </div>
                <span className="text-white/70 text-sm leading-snug pt-1.5">{fact.label}</span>
              </div>
            ))}
          </div>

          <div className="mb-20">
            <div className="glass-card rounded-2xl p-8 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 border border-white/5">
                  <i className="ri-file-list-3-line text-white/60 text-sm"></i>
                </div>
                <h2 className="text-2xl font-display font-semibold tracking-tight">{t('dtvVisa.requirementsTitle')}</h2>
              </div>
              <ul className="space-y-3">
                {reqs.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-white/60 text-sm">
                    <i className="ri-arrow-right-s-line text-white/30 mt-0.5 shrink-0"></i>{item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mb-20">
            <div className="glass-card rounded-2xl p-8 md:p-10 text-center">
              <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-white/5 border border-white/5 mb-4 mx-auto">
                <i className="ri-time-line text-white/60 text-xl"></i>
              </div>
              <h2 className="text-2xl font-display font-semibold tracking-tight mb-3">{t('dtvVisa.timelineTitle')}</h2>
              <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed">{t('dtvVisa.timelineDesc')}</p>
            </div>
          </div>

          <div className="relative bg-[#080808] rounded-2xl overflow-hidden p-10 md:p-14 text-center">
            <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
            <div className="relative">
              <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-4">{t('dtvVisa.qualifyTitle')}</h2>
              <p className="text-white/40 text-sm mb-8 max-w-md mx-auto">{t('dtvVisa.qualifyDesc')}</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto bg-white text-black px-6 py-3 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors inline-flex items-center justify-center gap-2">
                  <i className="ri-whatsapp-line text-lg"></i>{t('dtvVisa.qualifyWhatsApp')}
                </a>
                <a href="mailto:info@lumorasolution.org" className="w-full sm:w-auto glass-card px-6 py-3 rounded-lg text-sm font-medium text-white/80 hover:text-white whitespace-nowrap cursor-pointer transition-all inline-flex items-center justify-center gap-2">
                  <i className="ri-mail-line text-lg"></i>{t('dtvVisa.qualifyEmail')}
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}