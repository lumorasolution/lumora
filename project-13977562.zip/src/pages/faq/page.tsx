import { useState } from 'react';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { useTranslation } from 'react-i18next';

export default function Faq() {
  const { t } = useTranslation();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    { q: t('faq.q1'), a: t('faq.a1') },
    { q: t('faq.q2'), a: t('faq.a2') },
    { q: t('faq.q3'), a: t('faq.a3') },
    { q: t('faq.q4'), a: t('faq.a4') },
    { q: t('faq.q5'), a: t('faq.a5') },
    { q: t('faq.q6'), a: t('faq.a6') },
    { q: t('faq.q7'), a: t('faq.a7') },
    { q: t('faq.q8'), a: t('faq.a8') },
    { q: t('faq.q9'), a: t('faq.a9') },
  ];

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main className="pt-28 pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('faq.sectionLabel')}</p>
            <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-4">{t('faq.heading')}</h1>
            <p className="text-white/40 text-sm max-w-md mx-auto">{t('faq.subtitle')}</p>
          </div>

          <div className="space-y-3 mb-20">
            {faqs.map((faq, i) => {
              const isOpen = openIndex === i;
              return (
                <div key={i} className="glass-card rounded-2xl overflow-hidden transition-all duration-300">
                  <button type="button" onClick={() => setOpenIndex(isOpen ? null : i)}
                    className="w-full flex items-center justify-between gap-4 p-5 md:p-6 text-left cursor-pointer">
                    <span className="text-white/90 font-medium text-sm pr-4">{faq.q}</span>
                    <div className={`w-6 h-6 flex items-center justify-center shrink-0 rounded-full border border-white/10 transition-all duration-300 ${isOpen ? 'bg-white/10 rotate-45' : ''}`}>
                      <i className="ri-add-line text-white/60 text-xs"></i>
                    </div>
                  </button>
                  <div className={`transition-all duration-300 overflow-hidden ${isOpen ? 'max-h-96 pb-5 md:pb-6 px-5 md:px-6' : 'max-h-0'}`}>
                    <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="relative bg-[#080808] rounded-2xl overflow-hidden p-10 md:p-14 text-center">
            <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
            <div className="relative">
              <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-4">{t('faq.stillQuestions')}</h2>
              <p className="text-white/40 text-sm mb-8 max-w-md mx-auto leading-relaxed">{t('faq.stillDesc')}</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto bg-white text-black px-6 py-3 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors inline-flex items-center justify-center gap-2">
                  <i className="ri-whatsapp-line text-lg"></i>{t('faq.stillWhatsApp')}
                </a>
                <a href="mailto:info@lumorasolution.org" className="w-full sm:w-auto glass-card px-6 py-3 rounded-lg text-sm font-medium text-white/80 hover:text-white whitespace-nowrap cursor-pointer transition-all inline-flex items-center justify-center gap-2">
                  <i className="ri-mail-line text-lg"></i>{t('faq.stillEmail')}
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}