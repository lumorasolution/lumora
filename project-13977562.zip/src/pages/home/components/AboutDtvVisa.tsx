import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const eligibleGroups = [
  { icon: 'ri-computer-line', titleKey: 'about.group1Title', descKey: 'about.group1Desc' },
  { icon: 'ri-briefcase-line', titleKey: 'about.group2Title', descKey: 'about.group2Desc' },
  { icon: 'ri-global-line', titleKey: 'about.group3Title', descKey: 'about.group3Desc' },
  { icon: 'ri-group-2-line', titleKey: 'about.group4Title', descKey: 'about.group4Desc' },
];

export default function AboutDtvVisa() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  const keyFacts = [
    { icon: 'ri-calendar-2-line', value: t('about.fact1Value'), label: t('about.fact1Label'), desc: t('about.fact1Desc'), span: 'large' },
    { icon: 'ri-timer-2-line', value: t('about.fact2Value'), label: t('about.fact2Label'), desc: t('about.fact2Desc'), span: 'small' },
    { icon: 'ri-plane-line', value: t('about.fact3Value'), label: t('about.fact3Label'), desc: t('about.fact3Desc'), span: 'small' },
    { icon: 'ri-bank-line', value: t('about.fact4Value'), label: t('about.fact4Label'), desc: t('about.fact4Desc'), span: 'large' },
  ];

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) { setVisible(true); observer.disconnect(); }
      },
      { threshold: 0.08, rootMargin: '0px 0px -50px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 md:py-32 px-6 md:px-10 lg:px-16 bg-[#0a0806] overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[700px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(217,180,130,0.05) 0%, transparent 65%)' }} />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className={`text-center mb-16 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#d9b482]/30 bg-[#d9b482]/8 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#d9b482] animate-pulse"></span>
            <span className="text-xs font-mono uppercase tracking-widest text-[#d9b482]/90 font-medium">{t('about.badge')}</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight mb-5">
            {t('about.heading1')}<br /><span className="title-shimmer">{t('about.heading2')}</span>
          </h2>
          <p className="text-white/40 max-w-2xl mx-auto text-sm leading-relaxed">{t('about.subtitle')}</p>
        </div>

        <div className={`grid grid-cols-12 gap-4 mb-16 transition-all duration-700 delay-150 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          {keyFacts.map((fact, i) => {
            const isLarge = fact.span === 'large';
            return (
              <div key={fact.value} className={`group hover-grow relative overflow-hidden rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:border-[#d9b482]/20 transition-all duration-500 ${isLarge ? 'col-span-12 md:col-span-7' : 'col-span-12 md:col-span-5'}`}>
                <div className="absolute top-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(217,180,130,0.4), transparent)' }} />
                <div className={`relative z-10 flex flex-col ${isLarge ? 'p-8 md:p-10' : 'p-6 md:p-8'}`}>
                  <div className="flex items-center gap-3 mb-6">
                    <div className={`flex items-center justify-center rounded-xl bg-[#d9b482]/5 border border-[#d9b482]/8 shrink-0 group-hover:bg-[#d9b482]/10 group-hover:border-[#d9b482]/20 transition-all duration-300 ${isLarge ? 'w-11 h-11' : 'w-9 h-9'}`}>
                      <i className={`${fact.icon} text-[#d9b482]/70 ${isLarge ? 'text-xl' : 'text-lg'}`}></i>
                    </div>
                    <span className="text-white/30 text-xs font-mono uppercase tracking-wider">{fact.label}</span>
                  </div>
                  <div className={`font-display font-semibold tracking-tight text-white mb-3 ${isLarge ? 'text-4xl md:text-5xl' : 'text-3xl md:text-4xl'}`}>{fact.value}</div>
                  <p className={`text-white/35 leading-relaxed ${isLarge ? 'text-sm max-w-sm' : 'text-xs max-w-xs'}`}>{fact.desc}</p>
                </div>
                <div className="absolute bottom-0 right-0 w-24 h-24 opacity-5 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none">
                  <i className={`${fact.icon} text-[#d9b482] text-8xl`}></i>
                </div>
              </div>
            );
          })}
        </div>

        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10 transition-all duration-700 delay-200 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          <div className="glass-card rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-[#d9b482]/5 border border-[#d9b482]/8 shrink-0">
                <i className="ri-information-line text-[#d9b482]/70 text-base"></i>
              </div>
              <h3 className="text-base font-semibold tracking-tight text-white">{t('about.whatIsTitle')}</h3>
            </div>
            <p className="text-white/45 text-sm leading-relaxed mb-4" dangerouslySetInnerHTML={{ __html: t('about.whatIsDesc') }}></p>
            <ul className="space-y-2.5">
              {[t('about.req1'), t('about.req2'), t('about.req3'), t('about.req4')].map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-white/40 text-xs">
                  <i className="ri-arrow-right-s-line text-[#d9b482]/40 mt-0.5 shrink-0"></i>{item}
                </li>
              ))}
            </ul>
          </div>
          <div className="glass-card rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-[#d9b482]/5 border border-[#d9b482]/8 shrink-0">
                <i className="ri-user-search-line text-[#d9b482]/70 text-base"></i>
              </div>
              <h3 className="text-base font-semibold tracking-tight text-white">{t('about.whoTitle')}</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {eligibleGroups.map((group) => (
                <div key={group.titleKey} className="flex items-start gap-3 rounded-xl bg-white/[0.02] border border-white/[0.04] p-4 hover:border-white/10 transition-all duration-300">
                  <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#d9b482]/5 border border-[#d9b482]/8 shrink-0">
                    <i className={`${group.icon} text-[#d9b482]/60 text-sm`}></i>
                  </div>
                  <div>
                    <div className="text-white/80 text-xs font-semibold mb-0.5">{t(group.titleKey)}</div>
                    <div className="text-white/30 text-xs leading-snug">{t(group.descKey)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className={`flex flex-col sm:flex-row items-center justify-between gap-5 glass-card rounded-2xl px-8 py-6 transition-all duration-700 delay-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          <div>
            <p className="text-white/70 text-sm font-medium mb-0.5">{t('about.ctaTitle')}</p>
            <p className="text-white/30 text-xs">{t('about.ctaSub')}</p>
          </div>
          <Link to="/dtv-visa" className="shrink-0 inline-flex items-center gap-2 bg-[#d9b482]/10 hover:bg-[#d9b482]/18 border border-[#d9b482]/20 hover:border-[#d9b482]/35 text-[#d9b482] text-sm font-medium px-6 py-3 rounded-xl transition-all duration-300 whitespace-nowrap cursor-pointer">
            {t('about.ctaBtn')}<i className="ri-arrow-right-line text-base"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}