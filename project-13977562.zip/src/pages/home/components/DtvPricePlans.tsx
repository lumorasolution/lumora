import { useEffect, useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

export default function DtvPricePlans() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(1);

  const plans = [
    {
      key: 'compass', icon: 'ri-compass-3-line',
      features: ['f1', 'f2', 'f3', 'f4', 'f5', 'f6'],
      cta: t('plans.cta'),
      popular: false,
      whatsappUrl: `https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.compass'))}`,
    },
    {
      key: 'pathway', icon: 'ri-route-line',
      features: ['f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7'],
      cta: t('plans.cta'),
      popular: true,
      whatsappUrl: `https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.pathway'))}`,
    },
    {
      key: 'concierge', icon: 'ri-vip-crown-line',
      features: ['f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8'],
      cta: t('plans.cta'),
      popular: false,
      whatsappUrl: `https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.concierge'))}`,
    },
  ];

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.08, rootMargin: '0px 0px -50px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') { e.preventDefault(); setSelectedIndex((p) => (p === 0 ? plans.length - 1 : p - 1)); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); setSelectedIndex((p) => (p === plans.length - 1 ? 0 : p + 1)); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const isSelected = useCallback((index: number) => index === selectedIndex, [selectedIndex]);
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${((e.clientX - rect.left) / rect.width) * 100}%`);
    card.style.setProperty('--my', `${((e.clientY - rect.top) / rect.height) * 100}%`);
  }, []);

  return (
    <section className="relative py-24 md:py-32 px-6 md:px-10 lg:px-16 bg-[#0f0c08] overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(217,180,130,0.035) 0%, transparent 65%)' }} />
      <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
      <div ref={sectionRef} className="relative max-w-6xl mx-auto z-10">
        <div className={`text-center mb-16 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
          <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('plans.sectionLabel')}</p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight mb-4">{t('plans.heading')}</h2>
          <p className="text-white/40 max-w-xl mx-auto text-sm leading-relaxed">{t('plans.subtitle')}</p>
        </div>

        <div className="relative">
          <button onClick={() => setSelectedIndex((p) => (p === 0 ? plans.length - 1 : p - 1))}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 md:-translate-x-6 z-20 flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/[0.08] bg-white/[0.03] hover:bg-[#d9b482]/10 hover:border-[#d9b482]/25 transition-all duration-300 cursor-pointer group/arrow"
            aria-label={t('plans.prevPlan')}>
            <i className="ri-arrow-left-s-line text-white/40 group-hover/arrow:text-[#d9b482] text-lg md:text-xl transition-colors duration-300"></i>
          </button>
          <button onClick={() => setSelectedIndex((p) => (p === plans.length - 1 ? 0 : p + 1))}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 md:translate-x-6 z-20 flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/[0.08] bg-white/[0.03] hover:bg-[#d9b482]/10 hover:border-[#d9b482]/25 transition-all duration-300 cursor-pointer group/arrow"
            aria-label={t('plans.nextPlan')}>
            <i className="ri-arrow-right-s-line text-white/40 group-hover/arrow:text-[#d9b482] text-lg md:text-xl transition-colors duration-300"></i>
          </button>

          <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 transition-all duration-700 delay-150 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
            style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
            {plans.map((plan, i) => {
              const active = isSelected(i);
              return (
                <div key={plan.key} role="option" aria-selected={active} tabIndex={0}
                  onClick={() => setSelectedIndex(i)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelectedIndex(i); } }}
                  className={`group hover-grow relative flex flex-col overflow-hidden rounded-2xl border transition-all duration-500 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-[#d9b482]/40 ${active ? 'border-[#d9b482]/30 bg-[#d9b482]/[0.05] md:-mt-4 md:mb-4 ring-1 ring-[#d9b482]/15' : 'border-white/[0.06] bg-white/[0.02] hover:border-[#d9b482]/20'}`}
                  style={{ transitionDelay: `${i * 0.1}s` }} onMouseMove={handleMouseMove}>
                  {plan.popular && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
                      <span className="inline-block px-4 py-1 text-[10px] font-mono uppercase tracking-wider text-[#0f0c08] bg-[#d9b482] rounded-full whitespace-nowrap">{t('plans.mostPopular')}</span>
                    </div>
                  )}
                  {active && !plan.popular && (
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
                      <span className="inline-block px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-[#0f0c08] bg-[#d9b482]/80 rounded-full whitespace-nowrap">{t('plans.selected')}</span>
                    </div>
                  )}
                  <div className="absolute top-0 left-0 right-0 h-px transition-opacity duration-500"
                    style={{ background: active ? 'linear-gradient(90deg, transparent, rgba(217,180,130,0.6), transparent)' : 'linear-gradient(90deg, transparent, rgba(217,180,130,0.4), transparent)', opacity: active ? 1 : 0 }} />
                  <div className="flex flex-col flex-1 p-6 md:p-8">
                    <div className={`flex items-center justify-center w-12 h-12 rounded-xl border mb-6 transition-all duration-300 ${active ? 'bg-[#d9b482]/10 border-[#d9b482]/25' : 'bg-[#d9b482]/5 border-[#d9b482]/8 group-hover:bg-[#d9b482]/10 group-hover:border-[#d9b482]/20'}`}>
                      <i className={`${plan.icon} text-lg transition-colors duration-300 ${active ? 'text-[#d9b482]' : 'text-[#d9b482]/70 group-hover:text-[#d9b482]/90'}`}></i>
                    </div>
                    <h3 className="text-white font-semibold text-lg tracking-tight mb-1">{t(`plans.${plan.key}.name`)}</h3>
                    <p className="text-[#d9b482]/60 text-xs font-mono uppercase tracking-wider mb-1">{t(`plans.${plan.key}.tagline`)}</p>
                    <p className="text-[#d9b482] text-2xl font-display font-semibold tracking-tight mb-4">{t(`plans.${plan.key}.price`)}</p>
                    <p className="text-white/40 text-sm leading-relaxed mb-6">{t(`plans.${plan.key}.desc`)}</p>
                    <div className="h-px bg-white/[0.05] mb-6" />
                    <ul className="space-y-3 flex-1 mb-8">
                      {plan.features.map((fKey) => (
                        <li key={fKey} className="flex items-start gap-3">
                          <div className="shrink-0 mt-0.5"><i className={`ri-check-line text-xs transition-colors duration-300 ${active ? 'text-[#d9b482]' : 'text-[#d9b482]/50'}`}></i></div>
                          <span className="text-white/55 text-sm leading-snug">{t(`plans.${plan.key}.${fKey}`)}</span>
                        </li>
                      ))}
                    </ul>
                    <a href={plan.whatsappUrl} target="_blank" rel="noopener noreferrer"
                      className={`w-full py-3 rounded-xl text-sm font-semibold tracking-tight transition-all duration-300 whitespace-nowrap inline-block text-center ${active ? 'bg-[#d9b482] text-[#0f0c08] hover:bg-[#e0c08f] active:scale-[0.98]' : 'bg-white/[0.04] text-white/70 border border-white/[0.08] hover:bg-white/[0.08] hover:text-white hover:border-white/[0.15]'}`}>
                      {plan.cta}
                    </a>
                  </div>
                  <div className={`absolute bottom-0 right-0 w-16 h-16 transition-opacity duration-500 pointer-events-none ${active ? 'opacity-10' : 'opacity-5 group-hover:opacity-10'}`}>
                    <i className={`${plan.icon} text-[#d9b482] text-6xl`}></i>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center gap-2 mt-8">
            {plans.map((_, i) => (
              <button key={i} onClick={() => setSelectedIndex(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 cursor-pointer ${isSelected(i) ? 'bg-[#d9b482] w-6' : 'bg-white/[0.12] hover:bg-white/[0.25]'}`}
                aria-label={t('plans.selectPlan', { name: t(`plans.${plans[i].key}.name`) })} />
            ))}
          </div>
          <p className="text-center text-white/15 text-xs mt-4 font-mono">{t('plans.keyboardHint')}</p>
        </div>
      </div>
    </section>
  );
}