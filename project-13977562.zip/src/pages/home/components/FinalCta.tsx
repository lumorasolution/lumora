import { useEffect, useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import Magnetic from '@/components/base/Magnetic';

export default function FinalCta() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.15, rootMargin: '0px 0px -40px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const handleSectionMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const section = e.currentTarget;
    const rect = section.getBoundingClientRect();
    section.style.setProperty('--mx', `${((e.clientX - rect.left) / rect.width) * 100}%`);
    section.style.setProperty('--my', `${((e.clientY - rect.top) / rect.height) * 100}%`);
  }, []);

  const handleBtnMouseMove = useCallback((e: React.MouseEvent<HTMLAnchorElement>) => {
    const btn = e.currentTarget;
    const rect = btn.getBoundingClientRect();
    btn.style.setProperty('--mx', `${((e.clientX - rect.left) / rect.width) * 100}%`);
    btn.style.setProperty('--my', `${((e.clientY - rect.top) / rect.height) * 100}%`);
  }, []);

  return (
    <section ref={sectionRef} className="cta-section-glow relative py-24 md:py-32 px-6 md:px-10 lg:px-16 bg-[#0f0c08] overflow-hidden" onMouseMove={handleSectionMouseMove}>
      <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0806] via-transparent to-transparent" />
      <div className="relative max-w-2xl mx-auto text-center z-10">
        <h2 data-section-entrance style={{ animationDelay: '7.3s', transitionDelay: '0.1s' }} className={`final-cta-item text-3xl md:text-5xl font-display font-semibold tracking-tight mb-6 ${visible ? 'final-cta-visible' : ''}`}>
          <span className="title-shimmer">{t('finalCta.line1')}</span><br />
          <span className="text-white/80">{t('finalCta.line2')}</span>
        </h2>
        <p data-section-entrance style={{ animationDelay: '7.45s', transitionDelay: '0.25s' }} className={`final-cta-item text-white/40 text-sm leading-relaxed mb-10 max-w-lg mx-auto ${visible ? 'final-cta-visible' : ''}`}>
          {t('finalCta.desc')}
        </p>
        <div data-section-entrance style={{ animationDelay: '7.6s', transitionDelay: '0.4s' }} className={`final-cta-item flex flex-col sm:flex-row items-center justify-center gap-4 mb-8 ${visible ? 'final-cta-visible' : ''}`}>
          <Magnetic className="w-full sm:w-auto">
            <a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto bg-white text-black px-8 py-3.5 rounded-lg text-sm font-medium hover:bg-gray-100 hover:scale-[1.03] hover:shadow-[0_0_32px_rgba(255,255,255,0.12)] whitespace-nowrap cursor-pointer transition-all duration-300 inline-flex items-center justify-center gap-2">
              <i className="ri-whatsapp-line text-lg"></i>{t('finalCta.whatsapp')}
            </a>
          </Magnetic>
          <Magnetic className="w-full sm:w-auto">
            <a href="mailto:info@lumorasolution.org" onMouseMove={handleBtnMouseMove} className="cta-btn-email w-full sm:w-auto glass-card px-8 py-3.5 rounded-lg text-sm font-medium text-white/90 hover:text-white whitespace-nowrap cursor-pointer transition-all inline-flex items-center justify-center gap-2">
              <i className="ri-mail-line text-lg"></i>{t('finalCta.email')}
            </a>
          </Magnetic>
        </div>
        <div data-section-entrance style={{ animationDelay: '7.75s', transitionDelay: '0.55s' }} className={`final-cta-item flex flex-wrap items-center justify-center gap-5 text-sm text-white/55 font-mono ${visible ? 'final-cta-visible' : ''}`}>
          <span className="cta-badge flex items-center gap-1.5 cursor-default"><i className="ri-mail-line"></i> {t('finalCta.infoReply')}</span>
          <span className="cta-badge flex items-center gap-1.5 cursor-default"><i className="ri-whatsapp-line"></i> {t('finalCta.infoWhatsApp')}</span>
          <span className="cta-badge flex items-center gap-1.5 cursor-default"><i className="ri-shield-check-line"></i> {t('finalCta.infoFree')}</span>
          <span className="cta-badge flex items-center gap-1.5 cursor-default"><i className="ri-hand-heart-line"></i> {t('finalCta.infoCommitment')}</span>
        </div>
      </div>
    </section>
  );
}