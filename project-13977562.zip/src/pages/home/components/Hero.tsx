import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Magnetic from '@/components/base/Magnetic';

export default function Hero() {
  const { t } = useTranslation();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image with dark overlay */}
      <div className="absolute inset-0 hero-bg-entrance">
        <img
          src="https://readdy.ai/api/search-image?query=Elegant%20premium%20dark%20background%20with%20subtle%20silk-like%20flowing%20fabric%20texture%20in%20deep%20charcoal%20and%20warm%20ivory%20tones%2C%20soft%20diffused%20golden%20hour%20lighting%20from%20the%20top%20left%20corner%20creating%20a%20gentle%20atmospheric%20glow%2C%20luxurious%20marble-like%20veining%20patterns%20barely%20visible%20in%20the%20shadows%2C%20sophisticated%20and%20refined%20corporate%20aesthetic%2C%20abstract%20and%20modern%2C%20no%20text%20no%20people%2C%20high-end%20interior%20design%20photography%20style%20with%20shallow%20depth%20of%20field%2C%20clean%20and%20trustworthy%20professional%20atmosphere%2C%20subtle%20warm%20amber%20undertones%20blending%20with%20cool%20slate%20gray%20surfaces%2C%20minimal%20yet%20rich%20visual%20depth%2C%20editorial%20quality%20lighting%20with%20very%20soft%20natural%20falloff&width=1920&height=1080&seq=lumora-hero-bg-v3&orientation=landscape&nocache=true"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-[#0a0806]" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center pt-20">
        {/* Badge */}
        <div className="hero-badge inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#d9b482]/10 bg-[#d9b482]/5 text-[#f5f0e8]/80 text-xs font-mono mb-8">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          {t('hero.badge')}
        </div>

        {/* Animated headline */}
        <div className="mb-6">
          {/* Tagline */}
          <p className="hero-tagline text-sm md:text-base font-mono text-white/50 mb-4 tracking-[0.3em] uppercase">
            <span className="hero-word">{t('hero.taglinePart1')}</span>{' '}
            <span className="hero-word">{t('hero.taglinePart2')}</span>
          </p>

          {/* Main heading */}
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-display font-semibold tracking-tight leading-tight">
            <span className="hero-line block text-white/90">
              {t('hero.heading1')}
            </span>
            <span className="hero-line hero-line-accent block text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-100 to-amber-300 bg-[length:200%_100%] animate-shimmer-text">
              {t('hero.heading2')}
            </span>
          </h1>
        </div>

        {/* Description */}
        <p className="hero-desc text-white/70 text-base md:text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
          {t('hero.desc')}
        </p>

        {/* CTA buttons */}
        <div className="hero-cta flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
          <Magnetic className="w-full sm:w-auto">
            <a
              href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-white text-black px-8 py-3.5 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors inline-flex items-center justify-center gap-2"
            >
              <i className="ri-whatsapp-line text-lg"></i>
              {t('hero.ctaPrimary')}
            </a>
          </Magnetic>
          <Magnetic className="w-full sm:w-auto">
            <Link
              to="/pricing"
              className="w-full sm:w-auto glass-card px-8 py-3.5 rounded-lg text-sm font-medium text-white/90 hover:text-white whitespace-nowrap cursor-pointer transition-all inline-flex items-center justify-center gap-2"
            >
              <i className="ri-money-dollar-circle-line text-lg"></i>
              {t('hero.ctaSecondary')}
            </Link>
          </Magnetic>
        </div>

        {/* Bottom info */}
        <div className="hero-info flex flex-wrap items-center justify-center gap-5 text-sm text-white/55 font-mono">
          <span className="flex items-center gap-1.5">
            <i className="ri-mail-line"></i> {t('hero.infoReply')}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="ri-whatsapp-line"></i> {t('hero.infoWhatsApp')}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="ri-shield-check-line"></i> {t('hero.infoFree')}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="ri-hand-heart-line"></i> {t('hero.infoCommitment')}
          </span>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="hero-scroll-indicator absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/15 z-20">
        <span className="text-[10px] font-mono uppercase tracking-widest">{t('hero.scroll')}</span>
        <div className="hero-scroll-line w-px h-6 bg-gradient-to-b from-white/30 to-transparent" />
      </div>
    </section>
  );
}