import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

export default function StatsMarquee() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.05, rootMargin: '0px 0px -20px 0px' },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const stats = [
    { value: t('stats.value5Years'), label: t('stats.visaValidity') },
    { value: t('stats.value180Days'), label: t('stats.perEntry') },
    { value: t('stats.valueStartingFrom'), label: t('stats.startingFrom') },
    { value: t('stats.valueFree'), label: t('stats.freeCheck') },
    { value: t('stats.valueReplyTime'), label: t('stats.replyTime') },
    { value: t('stats.valueProcessing'), label: t('stats.processing') },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative -mt-2 py-12 border-b border-[#d9b482]/5 overflow-hidden bg-[#0f0c08]"
    >
      <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-[#0a0806] to-transparent pointer-events-none z-10" />
      <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />

      <div
        className={`relative flex gap-16 animate-marquee whitespace-nowrap transition-all duration-1000 ${
          visible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {[...stats, ...stats].map((stat, i) => (
          <div key={i} className="flex items-center gap-3 shrink-0">
            <span className="text-2xl md:text-3xl font-display font-semibold text-white/90">
              {stat.value}
            </span>
            <span className="text-xs font-mono text-white/30 uppercase tracking-wider">
              {stat.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}