import { useEffect, useRef, useState, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

export default function TrustSection() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.1, rootMargin: '0px 0px -60px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    card.style.setProperty('--mx', `${((e.clientX - rect.left) / rect.width) * 100}%`);
    card.style.setProperty('--my', `${((e.clientY - rect.top) / rect.height) * 100}%`);
  }, []);

  const trustCards = [
    { icon: 'ri-shield-check-line', title: t('trust.card1Title'), text: t('trust.card1Text') },
    { icon: 'ri-road-map-line', title: t('trust.card2Title'), text: t('trust.card2Text') },
    { icon: 'ri-chat-smile-2-line', title: t('trust.card3Title'), text: t('trust.card3Text') },
    { icon: 'ri-refund-2-line', title: t('trust.card4Title'), text: t('trust.card4Text') },
  ];

  const extras = [t('trust.tag1'), t('trust.tag2'), t('trust.tag3'), t('trust.tag4')];

  return (
    <section className="relative py-24 md:py-32 px-6 md:px-10 lg:px-16 bg-[#0a0806] overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(217,180,130,0.035) 0%, transparent 65%)' }} />
      <div ref={sectionRef} className="max-w-5xl mx-auto relative z-10">
        <div data-section-entrance style={{ animationDelay: '3.7s' }} className={`text-center mb-16 trust-header-hidden ${visible ? 'trust-header-visible' : ''}`}>
          <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('trust.sectionLabel')}</p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight mb-4">{t('trust.heading')}</h2>
          <p className="text-white/40 max-w-xl mx-auto text-sm leading-relaxed">{t('trust.subtitle')}</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {trustCards.map((card, i) => (
            <div key={card.title} className={`trust-card trust-card-glow glass-card rounded-2xl p-6 text-center cursor-pointer card-entrance ${visible ? 'trust-card-visible' : ''}`}
              style={{ animationDelay: `${3.85 + i * 0.13}s`, transitionDelay: `${i * 0.1}s` }} onMouseMove={handleMouseMove}>
              <span className="trust-card-number">{String(i + 1).padStart(2, '0')}</span>
              <div className="trust-card-icon relative z-10 w-12 h-12 flex items-center justify-center rounded-xl bg-[#d9b482]/5 border border-[#d9b482]/8 mb-4 mx-auto">
                <i className={`${card.icon} text-white/70 text-lg`} />
              </div>
              <div className="relative z-10">
                <h3 className="text-white font-semibold mb-2 text-sm tracking-tight">{card.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{card.text}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          {extras.map((item, i) => (
            <span key={item} className={`trust-tag-item card-entrance px-4 py-2 rounded-full border border-[#d9b482]/8 text-white/40 text-xs font-mono bg-[#d9b482]/[0.02] cursor-default ${visible ? 'trust-tag-visible' : ''}`}
              style={{ animationDelay: `${4.4 + i * 0.1}s`, transitionDelay: `${0.5 + i * 0.1}s` }}>{item}</span>
          ))}
        </div>
      </div>
    </section>
  );
}