import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

export default function WhyChooseUs() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  const advantages = [
    {
      icon: 'ri-shield-check-line',
      title: t('why.card1Title'),
      desc: t('why.card1Desc'),
      stat: t('why.card1Stat'),
      span: 'large',
    },
    {
      icon: 'ri-refund-line',
      title: t('why.card2Title'),
      desc: t('why.card2Desc'),
      stat: t('why.card2Stat'),
      span: 'small',
    },
    {
      icon: 'ri-eye-line',
      title: t('why.card3Title'),
      desc: t('why.card3Desc'),
      stat: t('why.card3Stat'),
      span: 'small',
    },
    {
      icon: 'ri-customer-service-2-line',
      title: t('why.card4Title'),
      desc: t('why.card4Desc'),
      stat: t('why.card4Stat'),
      span: 'large',
    },
  ];

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.08, rootMargin: '0px 0px -50px 0px' },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 md:py-32 px-6 md:px-10 lg:px-16 bg-[#080808] overflow-hidden"
    >
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(217,180,130,0.04) 0%, transparent 65%)' }}
      />
      <div className="absolute inset-0 tech-grid tech-grid-mask opacity-20 pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div
          className={`text-center mb-16 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}
        >
          <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('why.sectionLabel')}</p>
          <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight mb-4">{t('why.heading')}</h2>
          <p className="text-white/40 max-w-xl mx-auto text-sm leading-relaxed">{t('why.subtitle')}</p>
        </div>

        <div
          className={`grid grid-cols-12 gap-4 mb-10 transition-all duration-700 delay-150 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          style={{ transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)' }}
        >
          {advantages.map((item, i) => {
            const isLarge = item.span === 'large';
            const colClass = isLarge ? 'col-span-12 md:col-span-7' : 'col-span-12 md:col-span-5';
            const orderClass = i === 0 ? 'md:order-1' : i === 1 ? 'md:order-2' : i === 2 ? 'md:order-3' : 'md:order-4';

            return (
              <div
                key={item.title}
                className={`${colClass} ${orderClass} hover-grow group relative overflow-hidden rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:border-[#d9b482]/20 transition-all duration-500`}
              >
                <div className="absolute top-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(217,180,130,0.4), transparent)' }} />
                <div className={`relative z-10 flex flex-col ${isLarge ? 'p-8 md:p-10' : 'p-6 md:p-8'}`}>
                  <div className="flex items-center justify-between mb-6">
                    <div className={`flex items-center justify-center rounded-xl bg-[#d9b482]/5 border border-[#d9b482]/8 group-hover:bg-[#d9b482]/10 group-hover:border-[#d9b482]/20 transition-all duration-300 ${isLarge ? 'w-11 h-11' : 'w-9 h-9'}`}>
                      <i className={`${item.icon} text-[#d9b482]/70 ${isLarge ? 'text-xl' : 'text-lg'}`}></i>
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#d9b482]/50 border border-[#d9b482]/10 px-2.5 py-1 rounded-full">{item.stat}</span>
                  </div>
                  <h3 className={`text-white font-semibold tracking-tight mb-3 ${isLarge ? 'text-lg' : 'text-sm'}`}>{item.title}</h3>
                  <p className={`text-white/40 leading-relaxed ${isLarge ? 'text-sm max-w-sm' : 'text-xs max-w-xs'}`}>{item.desc}</p>
                </div>
                <div className="absolute bottom-0 right-0 w-20 h-20 opacity-5 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none">
                  <i className={`${item.icon} text-[#d9b482] text-7xl`}></i>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}