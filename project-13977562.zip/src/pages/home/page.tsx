import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import Hero from './components/Hero';
import StatsMarquee from './components/StatsMarquee';
import AboutDtvVisa from './components/AboutDtvVisa';
import DtvPricePlans from './components/DtvPricePlans';
import WhyChooseUs from './components/WhyChooseUs';
import TrustSection from './components/TrustSection';
import FinalCta from './components/FinalCta';

export default function Home() {
  return (
    <div className="bg-[#0a0806] text-[#f5f0e8]">
      <Navbar transparent />
      <main>
        <Hero />
        <StatsMarquee />
        <AboutDtvVisa />
        <DtvPricePlans />
        <WhyChooseUs />
        <TrustSection />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}