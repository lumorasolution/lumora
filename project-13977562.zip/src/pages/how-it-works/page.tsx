import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

gsap.registerPlugin(ScrollTrigger);

export default function HowItWorks() {
  const { t } = useTranslation();

  const steps = [
    { num: '01', title: t('how.step1Title'), icon: 'ri-chat-check-line', paragraphs: [t('how.step1P1'), t('how.step1P2')] },
    { num: '02', title: t('how.step2Title'), icon: 'ri-file-text-line', paragraphs: [t('how.step2P1'), t('how.step2P2')] },
    { num: '03', title: t('how.step3Title'), icon: 'ri-send-plane-line', paragraphs: [t('how.step3P1'), t('how.step3P2')] },
    { num: '04', title: t('how.step4Title'), icon: 'ri-passport-line', paragraphs: [t('how.step4P1'), t('how.step4P2')] },
  ];

  const containerRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const cards = containerRef.current.querySelectorAll('.step-card');
    const dots = containerRef.current.querySelectorAll('.step-dot');
    const icons = containerRef.current.querySelectorAll('.step-icon');

    const cardTween = gsap.fromTo(cards, { opacity: 0, y: 80, scale: 0.96 }, {
      opacity: 1, y: 0, scale: 1, duration: 0.7, stagger: 0.2, ease: 'power3.out',
      scrollTrigger: { trigger: containerRef.current, start: 'top 75%', end: 'bottom 20%', toggleActions: 'play none none reverse' },
    });

    const dotTween = gsap.fromTo(dots, { scale: 0.5, opacity: 0.2, backgroundColor: 'rgba(255,255,255,0.2)' }, {
      scale: 1, opacity: 1, backgroundColor: 'rgba(255,255,255,0.9)', duration: 0.5, stagger: 0.2, ease: 'back.out(2)',
      scrollTrigger: { trigger: containerRef.current, start: 'top 70%', end: 'bottom 30%', toggleActions: 'play none none reverse' },
    });

    const iconTween = gsap.fromTo(icons, { opacity: 0.5, scale: 0.9 }, {
      opacity: 1, scale: 1, duration: 0.5, stagger: 0.2, ease: 'power2.out',
      scrollTrigger: { trigger: containerRef.current, start: 'top 70%', end: 'bottom 30%', toggleActions: 'play none none reverse' },
    });

    const tlFill = gsap.fromTo(timelineRef.current, { scaleY: 0 }, {
      scaleY: 1, ease: 'none',
      scrollTrigger: { trigger: containerRef.current, start: 'top 60%', end: 'bottom 40%', scrub: 0.8 },
    });

    return () => { cardTween.scrollTrigger?.kill(); dotTween.scrollTrigger?.kill(); iconTween.scrollTrigger?.kill(); tlFill.scrollTrigger?.kill(); cardTween.kill(); dotTween.kill(); iconTween.kill(); tlFill.kill(); };
  }, []);

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main className="pt-28 pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-20">
            <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('how.sectionLabel')}</p>
            <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-4">{t('how.heading')}</h1>
            <p className="text-white/60 text-lg font-display mb-3">{t('how.tagline1')}</p>
            <p className="text-white/30 text-sm">{t('how.tagline2')}</p>
          </div>

          <div ref={containerRef} className="relative mb-20">
            <div className="absolute left-[1.625rem] top-0 bottom-0 w-px hidden md:block">
              <div className="absolute inset-0 bg-white/5" />
              <div ref={timelineRef} className="absolute top-0 left-0 w-full bg-gradient-to-b from-white/20 via-white/60 to-white/20 origin-top" style={{ height: '100%', transform: 'scaleY(0)' }} />
            </div>
            <div className="space-y-6">
              {steps.map((step) => (
                <div key={step.num} className="step-card relative glass-card rounded-2xl p-8 md:p-10">
                  <div className="flex flex-col md:flex-row md:items-start gap-6">
                    <div className="flex items-center gap-4 md:w-48 shrink-0">
                      <div className="relative flex items-center justify-center">
                        <span className="text-4xl font-display font-semibold text-white/10">{step.num}</span>
                        <div className="step-dot absolute -right-3 top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-white/20 hidden md:block" />
                      </div>
                      <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 md:hidden">
                        <i className={`${step.icon} text-white/60 text-sm`} />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="step-icon w-10 h-10 hidden md:flex items-center justify-center rounded-lg bg-white/5 border border-white/5">
                          <i className={`${step.icon} text-white/60 text-sm`} />
                        </div>
                        <h2 className="text-xl font-display font-semibold tracking-tight">{step.title}</h2>
                      </div>
                      <div className="space-y-3">
                        {step.paragraphs.map((p, pi) => (
                          <p key={pi} className="text-white/50 text-sm leading-relaxed">{p}</p>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative bg-[#080808] rounded-2xl overflow-hidden p-10 md:p-14 text-center">
            <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
            <div className="relative">
              <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-4">{t('how.ctaTitle')}</h2>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto bg-white text-black px-6 py-3 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors inline-flex items-center justify-center gap-2">
                  <i className="ri-whatsapp-line text-lg" />{t('how.ctaWhatsApp')}
                </a>
                <Link to="/contact" className="w-full sm:w-auto glass-card px-6 py-3 rounded-lg text-sm font-medium text-white/80 hover:text-white whitespace-nowrap cursor-pointer transition-all inline-flex items-center justify-center gap-2">
                  <i className="ri-mail-line text-lg" />{t('how.ctaContact')}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}