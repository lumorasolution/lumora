import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import DtvPricePlans from '@/pages/home/components/DtvPricePlans';
import { useTranslation } from 'react-i18next';

export default function Pricing() {
  const { t } = useTranslation();

  const includedItems = [
    t('pricing.included1'), t('pricing.included2'), t('pricing.included3'),
    t('pricing.included4'), t('pricing.included5'), t('pricing.included6'),
  ];

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main>
        <section className="pt-28 pb-8 px-6 md:px-10 lg:px-16">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('pricing.sectionLabel')}</p>
            <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-4">{t('pricing.heading')}</h1>
            <p className="text-white/40 text-sm max-w-md mx-auto">{t('pricing.subtitle')}</p>
          </div>
        </section>
        <DtvPricePlans />
        <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-[#080808]">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-10 text-center">{t('pricing.includedHeading')}</h2>
            <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-8 md:p-10">
              <ul className="space-y-4">
                {includedItems.map((item, i) => (
                  <li key={i} className="flex items-start gap-4 group">
                    <div className="w-6 h-6 flex items-center justify-center shrink-0 rounded-full bg-white/5 border border-white/5 mt-0.5 group-hover:border-white/20 transition-colors">
                      <i className="ri-check-line text-white/70 text-xs"></i>
                    </div>
                    <span className="text-white/70 text-sm leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
        <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-10 text-center">{t('pricing.refundHeading')}</h2>
            <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-8 md:p-10">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 flex items-center justify-center shrink-0 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <i className="ri-shield-check-line text-white/60 text-lg"></i>
                </div>
                <p className="text-white/50 text-sm leading-relaxed">{t('pricing.refundDesc')}</p>
              </div>
            </div>
          </div>
        </section>
        <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-[#080808]">
          <div className="max-w-3xl mx-auto">
            <div className="relative bg-[#0a0a0a] rounded-2xl overflow-hidden p-10 md:p-14 text-center border border-white/[0.04]">
              <div className="absolute inset-0 tech-grid tech-grid-mask opacity-30 pointer-events-none" />
              <div className="relative">
                <h2 className="text-2xl md:text-3xl font-display font-semibold tracking-tight mb-4">{t('pricing.questionsTitle')}</h2>
                <p className="text-white/40 text-sm mb-8 max-w-md mx-auto">{t('pricing.questionsDesc')}</p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <a href={`https://wa.me/66610685808?text=${encodeURIComponent(t('whatsapp.generic'))}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto bg-white text-black px-6 py-3 rounded-lg text-sm font-medium hover:bg-gray-100 whitespace-nowrap cursor-pointer transition-colors inline-flex items-center justify-center gap-2">
                    <i className="ri-whatsapp-line text-lg"></i>{t('pricing.questionsWhatsApp')}
                  </a>
                  <a href="mailto:info@lumorasolution.org" className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-sm font-medium text-white/80 hover:text-white whitespace-nowrap cursor-pointer transition-all border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.06]">
                    <i className="ri-mail-line text-lg"></i>{t('pricing.questionsEmail')}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}