import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { useTranslation } from 'react-i18next';

export default function Privacy() {
  const { t } = useTranslation();
  return (
    <div className="bg-[#050505] text-white min-h-screen">
      <Navbar />
      <main className="pt-28 pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <p className="text-xs font-mono uppercase tracking-widest text-white/25 mb-4">{t('privacy.sectionLabel')}</p>
          <h1 className="text-4xl md:text-5xl font-display font-semibold tracking-tight mb-6">{t('privacy.heading')}</h1>
          <div className="glass-card rounded-2xl p-8 md:p-10 space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 flex items-center justify-center shrink-0 rounded-lg bg-white/5 border border-white/5"><i className="ri-lock-line text-white/60 text-sm"></i></div>
              <p className="text-white/60 text-sm leading-relaxed">{t('privacy.intro')}</p>
            </div>
            <div className="border-t border-white/5 pt-6 space-y-4">
              <h3 className="text-white font-medium text-sm">{t('privacy.collectTitle')}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{t('privacy.collectDesc')}</p>
              <h3 className="text-white font-medium text-sm">{t('privacy.useTitle')}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{t('privacy.useDesc')}</p>
              <h3 className="text-white font-medium text-sm">{t('privacy.retentionTitle')}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{t('privacy.retentionDesc')}</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}