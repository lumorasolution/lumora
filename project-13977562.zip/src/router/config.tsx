import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import DtvVisa from "../pages/dtv-visa/page";
import HowItWorks from "../pages/how-it-works/page";
import Pricing from "../pages/pricing/page";
import Faq from "../pages/faq/page";
import Contact from "../pages/contact/page";
import Privacy from "../pages/privacy/page";
import Terms from "../pages/terms/page";
import Refund from "../pages/refund/page";

const routes: RouteObject[] = [
  { path: "/", element: <Home /> },
  { path: "/dtv-visa", element: <DtvVisa /> },
  { path: "/how-it-works", element: <HowItWorks /> },
  { path: "/pricing", element: <Pricing /> },
  { path: "/faq", element: <Faq /> },
  { path: "/contact", element: <Contact /> },
  { path: "/privacy", element: <Privacy /> },
  { path: "/terms", element: <Terms /> },
  { path: "/refund", element: <Refund /> },
  { path: "*", element: <NotFound /> },
];

export default routes;